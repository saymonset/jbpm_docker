curl -X PUT -H 'Content-type: application/xml' -u 'kieserver:kieserver1!' --data @createHelloContainer.xml http://localhost:8080/kie-server-6.3.0.Final-ee7/services/rest/server/containers/hello
